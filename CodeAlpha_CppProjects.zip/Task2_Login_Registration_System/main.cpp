#include <iostream>
#include <fstream>
#include <string>
using namespace std;

void registerUser();
void loginUser();
bool userExists(const string &username);

int main() {
    int choice;
    cout << "===== LOGIN & REGISTRATION SYSTEM =====" << endl;
    cout << "1. Register\n2. Login\n3. Exit\n";
    cout << "Enter your choice: ";
    cin >> choice;

    switch (choice) {
        case 1: registerUser(); break;
        case 2: loginUser(); break;
        case 3: cout << "Goodbye!\n"; break;
        default: cout << "Invalid choice!\n";
    }
    return 0;
}

bool userExists(const string &username) {
    ifstream file("users.txt");
    string storedUser, storedPass;
    while (file >> storedUser >> storedPass) {
        if (storedUser == username)
            return true;
    }
    return false;
}

void registerUser() {
    string username, password;
    cout << "\n=== Register New User ===\n";
    cout << "Enter username: ";
    cin >> username;
    if (userExists(username)) {
        cout << "Username already exists!\n";
        return;
    }
    cout << "Enter password: ";
    cin >> password;
    ofstream file("users.txt", ios::app);
    file << username << " " << password << endl;
    file.close();
    cout << "Registration successful!\n";
}

void loginUser() {
    string username, password, storedUser, storedPass;
    cout << "\n=== User Login ===\n";
    cout << "Enter username: ";
    cin >> username;
    cout << "Enter password: ";
    cin >> password;

    ifstream file("users.txt");
    bool found = false;
    while (file >> storedUser >> storedPass) {
        if (storedUser == username && storedPass == password) {
            found = true;
            break;
        }
    }
    file.close();
    if (found)
        cout << "Login successful! Welcome, " << username << "!\n";
    else
        cout << "Invalid username or password.\n";
}
