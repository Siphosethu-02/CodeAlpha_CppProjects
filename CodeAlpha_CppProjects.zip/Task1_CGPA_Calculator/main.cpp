#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

double gradeToPoint(string grade) {
    if (grade == "A" || grade == "a") return 4.0;
    else if (grade == "B" || grade == "b") return 3.0;
    else if (grade == "C" || grade == "c") return 2.0;
    else if (grade == "D" || grade == "d") return 1.0;
    else if (grade == "F" || grade == "f") return 0.0;
    else return -1;
}

int main() {
    int numCourses;
    cout << "===== CGPA CALCULATOR =====" << endl;
    cout << "Enter number of courses: ";
    cin >> numCourses;

    double totalCredits = 0, totalGradePoints = 0;
    string grade;
    double credit;

    cout << "\nEnter details for each course:\n";
    for (int i = 1; i <= numCourses; ++i) {
        cout << "Course " << i << " grade (A-F): ";
        cin >> grade;
        cout << "Credit hours for course " << i << ": ";
        cin >> credit;

        double gradePoint = gradeToPoint(grade);
        if (gradePoint == -1) {
            cout << "Invalid grade entered! Try again.\n";
            i--;
            continue;
        }

        totalCredits += credit;
        totalGradePoints += (gradePoint * credit);
    }

    double cgpa = totalGradePoints / totalCredits;

    cout << fixed << setprecision(2);
    cout << "=============================\n";
    cout << "Total Credits: " << totalCredits << endl;
    cout << "Total Grade Points: " << totalGradePoints << endl;
    cout << "Your CGPA: " << cgpa << endl;
    cout << "=============================\n";

    return 0;
}
