# 🖥️ CodeAlpha C++ Internship Projects

This repository contains four C++ programming tasks completed as part of my CodeAlpha Internship Program.

## 📚 Projects
1. CGPA Calculator
2. Login & Registration System
3. Sudoku Solver
4. Banking System

Each project demonstrates practical use of OOP, file handling, and algorithms in C++.
