#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
using namespace std;

class Account {
private:
    string name, accountNumber;
    double balance;
public:
    Account(string n="", string accNo="", double bal=0.0) : name(n), accountNumber(accNo), balance(bal) {}

    void createAccount() {
        cout << "Enter Full Name: ";
        cin.ignore();
        getline(cin, name);
        cout << "Enter Account Number: ";
        cin >> accountNumber;
        cout << "Enter Initial Deposit: ";
        cin >> balance;

        ofstream file("accounts.txt", ios::app);
        file << name << "," << accountNumber << "," << balance << endl;
        file.close();

        cout << "Account successfully created!\n";
    }

    void displayAccounts() {
        ifstream file("accounts.txt");
        if (!file) { cout << "No account records found.\n"; return; }
        cout << "\n===== ACCOUNT LIST =====\n";
        string n, accNo; double bal;
        while (file >> ws && getline(file, n, ',') && getline(file, accNo, ',') && file >> bal)
            cout << left << setw(20) << n << setw(15) << accNo << "Balance: R" << bal << endl;
        file.close();
    }

    void deposit() {
        string accNo; double amount;
        cout << "Enter Account Number: "; cin >> accNo;
        cout << "Enter amount to deposit: "; cin >> amount;

        ifstream inFile("accounts.txt");
        ofstream tempFile("temp.txt");
        string n, a; double b; bool found = false;

        while (inFile >> ws && getline(inFile, n, ',') && getline(inFile, a, ',') && inFile >> b) {
            if (a == accNo) { b += amount; cout << "Deposit successful! New Balance: R" << b << endl; found = true; }
            tempFile << n << "," << a << "," << b << endl;
        }

        inFile.close(); tempFile.close();
        remove("accounts.txt"); rename("temp.txt", "accounts.txt");
        if (!found) cout << "Account not found.\n";
    }

    void withdraw() {
        string accNo; double amount;
        cout << "Enter Account Number: "; cin >> accNo;
        cout << "Enter amount to withdraw: "; cin >> amount;

        ifstream inFile("accounts.txt");
        ofstream tempFile("temp.txt");
        string n, a; double b; bool found = false;

        while (inFile >> ws && getline(inFile, n, ',') && getline(inFile, a, ',') && inFile >> b) {
            if (a == accNo) {
                if (b >= amount) { b -= amount; cout << "Withdrawal successful! New Balance: R" << b << endl; }
                else cout << "Insufficient funds.\n";
                found = true;
            }
            tempFile << n << "," << a << "," << b << endl;
        }

        inFile.close(); tempFile.close();
        remove("accounts.txt"); rename("temp.txt", "accounts.txt");
        if (!found) cout << "Account not found.\n";
    }

    void checkBalance() {
        string accNo; cout << "Enter Account Number: "; cin >> accNo;
        ifstream file("accounts.txt"); string n, a; double b; bool found = false;
        while (file >> ws && getline(file, n, ',') && getline(file, a, ',') && file >> b) {
            if (a == accNo) { cout << "Account Holder: " << n << "\nBalance: R" << b << endl; found = true; break; }
        }
        if (!found) cout << "Account not found.\n"; file.close();
    }
};

int main() {
    Account acc; int choice;
    do {
        cout << "\n===== SIMPLE BANKING SYSTEM =====\n";
        cout << "1. Create Account\n2. Display All Accounts\n3. Deposit Money\n4. Withdraw Money\n5. Check Balance\n6. Exit\n";
        cout << "Enter your choice: "; cin >> choice;

        switch (choice) {
            case 1: acc.createAccount(); break;
            case 2: acc.displayAccounts(); break;
            case 3: acc.deposit(); break;
            case 4: acc.withdraw(); break;
            case 5: acc.checkBalance(); break;
            case 6: cout << "Thank you for using our banking system!\n"; break;
            default: cout << "Invalid choice!\n";
        }
    } while (choice != 6);
    return 0;
}
